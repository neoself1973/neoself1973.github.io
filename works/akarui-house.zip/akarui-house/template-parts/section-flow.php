<?php
/**
 * 家ができるまでの流れ（カスタム投稿タイプ flow）
 *
 * @package Akarui_HOUSE
 */

$akarui_flow = new WP_Query(
	array(
		'post_type'      => 'flow',
		'posts_per_page' => 5,
		'orderby'        => 'menu_order date',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	)
);

/* flow が未登録のときはカンプどおりの初期値を出す */
$akarui_steps = array();
if ( $akarui_flow->have_posts() ) {
	while ( $akarui_flow->have_posts() ) {
		$akarui_flow->the_post();
		$akarui_steps[] = array(
			'title' => get_the_title(),
			'text'  => wp_strip_all_tags( get_the_content() ),
		);
	}
	wp_reset_postdata();
} else {
	$akarui_dummy = __( 'テキストテキストテキストテキストテキストテキストテキストテキスト テキストテキストテキストテキストテキストテキストテキストテキスト', 'akarui-house' );
	foreach ( array( 'ヒアリング', 'プラン提案', '契約', '着工', '完成' ) as $akarui_t ) {
		$akarui_steps[] = array(
			'title' => $akarui_t,
			'text'  => $akarui_dummy,
		);
	}
}
?>
<section class="flow" id="flow">
	<div class="container">
		<h2 class="sec-title"><?php esc_html_e( '家ができるまでの流れ', 'akarui-house' ); ?></h2>
		<p class="flow__lead"><?php esc_html_e( 'お問い合わせいただいてから、家が完成するまでの流れです。', 'akarui-house' ); ?></p>

		<div class="flow__body">
			<ol class="steps" aria-label="<?php echo esc_attr( sprintf( __( '家ができるまでの%dステップ', 'akarui-house' ), count( $akarui_steps ) ) ); ?>">
				<?php foreach ( $akarui_steps as $akarui_n => $akarui_s ) : ?>
					<li class="step">
						<span class="step__label"><?php echo esc_html( ( $akarui_n + 1 ) . '.' . $akarui_s['title'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ol>

			<ol class="details">
				<?php foreach ( $akarui_steps as $akarui_n => $akarui_s ) : ?>
					<li class="detail">
						<h3 class="detail__title">
							<span class="detail__num"><?php echo esc_html( (string) ( $akarui_n + 1 ) ); ?></span><?php echo esc_html( $akarui_s['title'] ); ?>
						</h3>
						<p class="detail__text"><?php echo esc_html( $akarui_s['text'] ); ?></p>
					</li>
				<?php endforeach; ?>
			</ol>
		</div>
	</div>
</section>
