<?php
/**
 * お問い合わせ（3つの入口）
 *
 * @package Akarui_HOUSE
 */

$akarui_boxes = array(
	array( 'icon' => 'icon-document.png', 'name' => __( '資料請求', 'akarui-house' ),  'url' => home_url( '/contact/document/' ) ),
	array( 'icon' => 'icon-seminar.png',  'name' => __( 'Web説明会', 'akarui-house' ), 'url' => home_url( '/contact/seminar/' ) ),
	array( 'icon' => 'icon-talk.png',     'name' => __( '個別相談', 'akarui-house' ),  'url' => home_url( '/contact/talk/' ) ),
);
?>
<section class="contact" id="contact">
	<div class="container">
		<h2 class="sec-title"><?php esc_html_e( 'お問い合わせ', 'akarui-house' ); ?></h2>
		<p class="contact__lead"><?php esc_html_e( 'お問い合わせは下記からお願いいたします。', 'akarui-house' ); ?></p>
		<ul class="contact__list">
			<?php foreach ( $akarui_boxes as $akarui_b ) : ?>
				<li>
					<a class="cbox" href="<?php echo esc_url( $akarui_b['url'] ); ?>">
						<img class="cbox__icon"
						     src="<?php echo esc_url( get_theme_file_uri( '/img/' . $akarui_b['icon'] ) ); ?>"
						     alt="" width="64" height="64" loading="lazy">
						<span class="cbox__name"><?php echo esc_html( $akarui_b['name'] ); ?></span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
