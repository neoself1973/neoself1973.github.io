<?php
/**
 * トップページ
 *
 * @package Akarui_HOUSE
 */

get_header();
?>
	<main id="main">
		<section class="mainvisual" aria-label="<?php esc_attr_e( 'メインビジュアル', 'akarui-house' ); ?>"></section>

		<div class="darkzone">
			<?php get_template_part( 'template-parts/section', 'works' ); ?>
			<?php get_template_part( 'template-parts/section', 'features' ); ?>
		</div>

		<?php get_template_part( 'template-parts/section', 'flow' ); ?>
		<?php get_template_part( 'template-parts/section', 'contact' ); ?>
	</main>
<?php
get_footer();
