<?php
/**
 * 建築事例 個別ページ
 *
 * @package Akarui_HOUSE
 */

get_header();
?>
	<main id="main">
		<section class="mainvisual" aria-label="<?php esc_attr_e( 'メインビジュアル', 'akarui-house' ); ?>"></section>

		<article class="entry">
			<div class="container">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<h1 class="sec-title"><?php the_title(); ?></h1>

					<?php if ( has_post_thumbnail() ) : ?>
						<div class="entry__thumb" style="margin-top:60px">
							<?php the_post_thumbnail( 'large' ); ?>
						</div>
					<?php endif; ?>

					<div class="entry__body">
						<?php the_content(); ?>
					</div>
				<?php endwhile; ?>

				<p style="margin-top:60px">
					<a class="notfound__back" href="<?php echo esc_url( get_post_type_archive_link( 'works' ) ); ?>">
						<?php esc_html_e( '建築事例一覧へ', 'akarui-house' ); ?>
					</a>
				</p>
			</div>
		</article>
	</main>
<?php
get_footer();
