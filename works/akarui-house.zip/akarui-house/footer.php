<?php
/**
 * フッター
 *
 * @package Akarui_HOUSE
 */
?>
	<footer class="footer">
		<nav class="fnav" aria-label="<?php esc_attr_e( 'フッターメニュー', 'akarui-house' ); ?>">
			<?php
			if ( has_nav_menu( 'footer' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_class'     => 'fnav__list',
						'depth'          => 1,
					)
				);
			} else {
				akarui_fallback_menu(
					array(
						'私たちについて' => home_url( '/about/' ),
						'サービス'       => home_url( '/service/' ),
						'商品情報'       => home_url( '/product/' ),
						'展示会'         => home_url( '/exhibition/' ),
						'暮らしの日記'   => home_url( '/diary/' ),
						'会社概要'       => home_url( '/company/' ),
					),
					'fnav__list'
				);
			}
			?>
		</nav>
		<p class="copyright">
			<?php
			printf(
				/* translators: 1: 年, 2: サイト名 */
				esc_html__( 'Copyright © %1$s %2$s All Rights Reserved.', 'akarui-house' ),
				esc_html( wp_date( 'Y' ) ),
				esc_html( get_bloginfo( 'name' ) )
			);
			?>
		</p>
	</footer>
</div><!-- /.wrapper -->

<a class="totop" id="totop" href="#top" aria-label="<?php esc_attr_e( 'ページ上部へ戻る', 'akarui-house' ); ?>"></a>

<?php wp_footer(); ?>
</body>
</html>
