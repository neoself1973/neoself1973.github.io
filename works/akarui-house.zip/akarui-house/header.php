<?php
/**
 * ヘッダー（PC：固定サイドメニュー / SP：固定ヘッダー＋ドロワー）
 *
 * @package Akarui_HOUSE
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link" href="#main"><?php esc_html_e( '本文へスキップ', 'akarui-house' ); ?></a>

<header class="sidebar" id="sidebar">
	<div class="sidebar__head">
		<p class="logo">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
				<?php if ( has_custom_logo() ) : ?>
					<?php the_custom_logo(); ?>
				<?php else : ?>
					<img src="<?php echo esc_url( get_theme_file_uri( '/img/logo.svg' ) ); ?>"
					     alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="206" height="60">
				<?php endif; ?>
			</a>
		</p>
		<button class="hamburger" id="hamburger" type="button"
		        aria-controls="drawer" aria-expanded="false"
		        aria-label="<?php esc_attr_e( 'メニューを開く', 'akarui-house' ); ?>">
			<span class="hamburger__bar"></span>
			<span class="hamburger__bar"></span>
			<span class="hamburger__bar"></span>
		</button>
	</div>

	<div class="sidebar__body" id="drawer">
		<nav class="gnav" aria-label="<?php esc_attr_e( 'メインメニュー', 'akarui-house' ); ?>">
			<?php
			if ( has_nav_menu( 'global' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'global',
						'container'      => false,
						'menu_class'     => 'gnav__list',
						'depth'          => 1,
					)
				);
			} else {
				akarui_fallback_menu(
					array(
						'私たちについて' => home_url( '/about/' ),
						'サービス'       => home_url( '/service/' ),
						'商品情報'       => home_url( '/product/' ),
						'展示会'         => home_url( '/exhibition/' ),
						'暮らしの日記'   => home_url( '/diary/' ),
						'会社概要'       => home_url( '/company/' ),
					),
					'gnav__list'
				);
			}
			?>
		</nav>
		<nav class="snsnav" aria-label="<?php esc_attr_e( 'ソーシャルメディア', 'akarui-house' ); ?>">
			<?php
			if ( has_nav_menu( 'sns' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'sns',
						'container'      => false,
						'menu_class'     => 'snsnav__list',
						'depth'          => 1,
					)
				);
			} else {
				akarui_fallback_menu(
					array(
						'Twitter'   => '#',
						'facebook'  => '#',
						'instagram' => '#',
					),
					'snsnav__list'
				);
			}
			?>
		</nav>
	</div>
</header>

<div class="wrapper" id="top">
	<div class="backdrop" aria-hidden="true"></div>
