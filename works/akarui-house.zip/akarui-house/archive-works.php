<?php
/**
 * 建築事例アーカイブ
 *
 * @package Akarui_HOUSE
 */

get_header();
?>
	<main id="main">
		<section class="mainvisual" aria-label="<?php esc_attr_e( 'メインビジュアル', 'akarui-house' ); ?>"></section>

		<section class="archive-works">
			<div class="container">
				<h1 class="sec-title"><?php post_type_archive_title(); ?></h1>

				<?php if ( have_posts() ) : ?>
					<ul class="works__list">
						<?php
						$akarui_i = 0;
						while ( have_posts() ) :
							the_post();
							?>
							<li class="card">
								<a class="card__link" href="<?php the_permalink(); ?>">
									<?php if ( has_post_thumbnail() ) : ?>
										<?php the_post_thumbnail( 'akarui-card', array( 'class' => 'card__img', 'loading' => 'lazy' ) ); ?>
									<?php else : ?>
										<img class="card__img" src="<?php echo esc_url( get_theme_file_uri( '/img/project1.jpg' ) ); ?>"
										     alt="" width="880" height="560" loading="lazy">
									<?php endif; ?>
									<span class="card__label"><?php echo esc_html( akarui_project_label( $akarui_i ) ); ?></span>
								</a>
							</li>
							<?php
							++$akarui_i;
						endwhile;
						?>
					</ul>

					<?php
					the_posts_pagination(
						array(
							'class'              => 'pager',
							'mid_size'           => 1,
							'prev_text'          => esc_html__( '前へ', 'akarui-house' ),
							'next_text'          => esc_html__( '次へ', 'akarui-house' ),
							'screen_reader_text' => esc_html__( 'ページ送り', 'akarui-house' ),
						)
					);
					?>
				<?php else : ?>
					<p class="is-empty"><?php esc_html_e( '建築事例はまだ登録されていません。', 'akarui-house' ); ?></p>
				<?php endif; ?>
			</div>
		</section>
	</main>
<?php
get_footer();
