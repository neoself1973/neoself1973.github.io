<?php
/**
 * 明るいHOUSEの特徴
 * 3枠のみの固定セクション。文言はカスタマイザーを用意せず、
 * テーマの翻訳ファイルで差し替える前提。
 *
 * @package Akarui_HOUSE
 */

$akarui_features = array(
	array(
		'en'   => 'design',
		'name' => __( 'デザイン', 'akarui-house' ),
		'text' => __( 'テキストテキストテキスト', 'akarui-house' ),
		'url'  => home_url( '/design/' ),
	),
	array(
		'en'   => 'quality',
		'name' => __( '性能', 'akarui-house' ),
		'text' => __( 'テキストテキストテキスト', 'akarui-house' ),
		'url'  => home_url( '/quality/' ),
	),
	array(
		'en'   => 'support',
		'name' => __( 'サポート', 'akarui-house' ),
		'text' => __( 'テキストテキストテキスト', 'akarui-house' ),
		'url'  => home_url( '/support/' ),
	),
);
?>
<section class="features" id="features">
	<div class="container">
		<h2 class="sec-title sec-title--light"><?php esc_html_e( '明るいHOUSEの特徴', 'akarui-house' ); ?></h2>
		<ul class="features__list">
			<?php foreach ( $akarui_features as $akarui_f ) : ?>
				<li class="feature">
					<a class="feature__circle" href="<?php echo esc_url( $akarui_f['url'] ); ?>">
						<span class="feature__en"><?php echo esc_html( $akarui_f['en'] ); ?></span>
					</a>
					<h3 class="feature__name"><?php echo esc_html( $akarui_f['name'] ); ?></h3>
					<p class="feature__text"><?php echo esc_html( $akarui_f['text'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
