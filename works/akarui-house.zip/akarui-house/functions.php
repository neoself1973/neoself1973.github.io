<?php
/**
 * Akarui HOUSE — テーマの基本設定
 *
 * @package Akarui_HOUSE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'AKARUI_VERSION' ) ) {
	define( 'AKARUI_VERSION', '1.0.0' );
}

/**
 * テーマサポート
 */
function akarui_setup() {
	load_theme_textdomain( 'akarui-house', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support(
		'html5',
		array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'width'       => 206,
			'height'      => 60,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);

	// 建築事例カードの比率（カンプ 402 × 256）。
	add_image_size( 'akarui-card', 880, 560, true );

	register_nav_menus(
		array(
			'global' => __( 'グローバルメニュー（サイドメニュー）', 'akarui-house' ),
			'sns'    => __( 'SNSメニュー', 'akarui-house' ),
			'footer' => __( 'フッターメニュー', 'akarui-house' ),
		)
	);
}
add_action( 'after_setup_theme', 'akarui_setup' );

/**
 * CSS / JS の読み込み
 */
function akarui_assets() {
	wp_enqueue_style(
		'akarui-googlefonts',
		'https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;700&display=swap',
		array(),
		null
	);
	wp_enqueue_style(
		'akarui-style',
		get_stylesheet_uri(),
		array( 'akarui-googlefonts' ),
		AKARUI_VERSION
	);
	wp_enqueue_script(
		'akarui-script',
		get_theme_file_uri( '/js/script.js' ),
		array(),
		AKARUI_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'akarui_assets' );

/**
 * メインビジュアルの固定背景画像。
 * カスタマイザーで指定がなければテーマ同梱のプレースホルダーを使う。
 */
function akarui_backdrop_url() {
	$id = (int) get_theme_mod( 'akarui_mainvisual_id', 0 );
	if ( $id ) {
		$url = wp_get_attachment_image_url( $id, 'full' );
		if ( $url ) {
			return $url;
		}
	}
	return get_theme_file_uri( '/img/mainvisual.jpg' );
}

/**
 * 固定背景だけはカスタマイザーで差し替えられるようにインラインで出す。
 */
function akarui_backdrop_style() {
	printf(
		'<style id="akarui-backdrop">.backdrop{background-image:url(%s)}</style>' . "\n",
		esc_url( akarui_backdrop_url() )
	);
}
add_action( 'wp_head', 'akarui_backdrop_style', 20 );

/**
 * カスタマイザー：メインビジュアル画像
 */
function akarui_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'akarui_mainvisual',
		array(
			'title'    => __( 'メインビジュアル', 'akarui-house' ),
			'priority' => 30,
		)
	);
	$wp_customize->add_setting(
		'akarui_mainvisual_id',
		array(
			'default'           => 0,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'akarui_mainvisual_id',
			array(
				'label'       => __( '固定背景に使う画像', 'akarui-house' ),
				'description' => __( '推奨 1400 × 760px 以上。指定がなければテーマ同梱のプレースホルダーを表示します。', 'akarui-house' ),
				'section'     => 'akarui_mainvisual',
				'mime_type'   => 'image',
			)
		)
	);
}
add_action( 'customize_register', 'akarui_customize_register' );

/**
 * body に admin-bar クラスを足す（固定要素の位置補正に使う）
 */
function akarui_body_class( $classes ) {
	if ( is_admin_bar_showing() ) {
		$classes[] = 'admin-bar';
	}
	return $classes;
}
add_filter( 'body_class', 'akarui_body_class' );

/**
 * メニュー未設定でもカンプどおりの並びが出るようにするフォールバック
 */
function akarui_fallback_menu( $items, $class ) {
	echo '<ul class="' . esc_attr( $class ) . '">';
	foreach ( $items as $label => $url ) {
		printf(
			'<li><a href="%s">%s</a></li>',
			esc_url( $url ),
			esc_html( $label )
		);
	}
	echo '</ul>';
}

/**
 * 建築事例のアーカイブ表示件数
 */
function akarui_pre_get_posts( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( $query->is_post_type_archive( 'works' ) ) {
		$query->set( 'posts_per_page', 8 );
	}
}
add_action( 'pre_get_posts', 'akarui_pre_get_posts' );

require get_template_directory() . '/inc/post-types.php';
