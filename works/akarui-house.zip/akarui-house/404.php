<?php
/**
 * 404
 *
 * @package Akarui_HOUSE
 */

get_header();
?>
	<main id="main">
		<section class="notfound">
			<div class="container">
				<p class="notfound__code">404</p>
				<p class="notfound__text"><?php esc_html_e( 'お探しのページは見つかりませんでした。', 'akarui-house' ); ?></p>
				<a class="notfound__back" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php esc_html_e( 'トップページへ戻る', 'akarui-house' ); ?>
				</a>
			</div>
		</section>
	</main>
<?php
get_footer();
