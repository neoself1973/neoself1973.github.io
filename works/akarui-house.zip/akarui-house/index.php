<?php
/**
 * 汎用テンプレート（アーカイブ・検索結果・ブログ一覧）
 *
 * @package Akarui_HOUSE
 */

get_header();
?>
	<main id="main">
		<section class="mainvisual" aria-label="<?php esc_attr_e( 'メインビジュアル', 'akarui-house' ); ?>"></section>

		<section class="entry">
			<div class="container">
				<h1 class="sec-title">
					<?php
					if ( is_search() ) {
						printf(
							/* translators: %s: 検索語 */
							esc_html__( '「%s」の検索結果', 'akarui-house' ),
							esc_html( get_search_query() )
						);
					} elseif ( is_archive() ) {
						the_archive_title();
					} else {
						echo esc_html( get_bloginfo( 'name' ) );
					}
					?>
				</h1>

				<?php if ( have_posts() ) : ?>
					<div class="entry__body" style="margin-top:60px">
						<?php
						while ( have_posts() ) :
							the_post();
							?>
							<article>
								<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<p class="entry__meta"><?php echo esc_html( get_the_date() ); ?></p>
								<?php the_excerpt(); ?>
							</article>
						<?php endwhile; ?>
					</div>
					<?php
					the_posts_pagination(
						array(
							'class'     => 'pager',
							'mid_size'  => 1,
							'prev_text' => esc_html__( '前へ', 'akarui-house' ),
							'next_text' => esc_html__( '次へ', 'akarui-house' ),
						)
					);
					?>
				<?php else : ?>
					<p class="is-empty" style="margin-top:60px"><?php esc_html_e( '記事が見つかりませんでした。', 'akarui-house' ); ?></p>
				<?php endif; ?>
			</div>
		</section>
	</main>
<?php
get_footer();
