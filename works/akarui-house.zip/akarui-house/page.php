<?php
/**
 * 固定ページ
 *
 * @package Akarui_HOUSE
 */

get_header();
?>
	<main id="main">
		<section class="mainvisual" aria-label="<?php esc_attr_e( 'メインビジュアル', 'akarui-house' ); ?>"></section>

		<article class="entry">
			<div class="container">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<h1 class="sec-title"><?php the_title(); ?></h1>
					<div class="entry__body" style="margin-top:60px">
						<?php the_content(); ?>
					</div>
				<?php endwhile; ?>
			</div>
		</article>
	</main>
<?php
get_footer();
