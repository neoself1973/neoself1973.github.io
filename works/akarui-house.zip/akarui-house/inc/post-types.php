<?php
/**
 * カスタム投稿タイプ
 *   works … 建築事例（アーカイブ・個別ページあり、アイキャッチ必須）
 *   flow  … 家づくりの流れ（並び順つき。個別ページは持たない）
 *
 * @package Akarui_HOUSE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 投稿タイプの登録
 */
function akarui_register_post_types() {

	/* ---------- 建築事例 ---------- */
	register_post_type(
		'works',
		array(
			'label'         => __( '建築事例', 'akarui-house' ),
			'labels'        => array(
				'name'               => __( '建築事例', 'akarui-house' ),
				'singular_name'      => __( '建築事例', 'akarui-house' ),
				'add_new_item'       => __( '建築事例を追加', 'akarui-house' ),
				'edit_item'          => __( '建築事例を編集', 'akarui-house' ),
				'all_items'          => __( '建築事例一覧', 'akarui-house' ),
				'featured_image'     => __( '事例の写真', 'akarui-house' ),
				'set_featured_image' => __( '事例の写真を設定', 'akarui-house' ),
			),
			'public'        => true,
			'has_archive'   => true,
			'menu_position' => 5,
			'menu_icon'     => 'dashicons-admin-home',
			'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
			'rewrite'       => array( 'slug' => 'works', 'with_front' => false ),
			'show_in_rest'  => true,
		)
	);

	/* ---------- 家づくりの流れ ---------- */
	register_post_type(
		'flow',
		array(
			'label'               => __( '家づくりの流れ', 'akarui-house' ),
			'labels'              => array(
				'name'          => __( '家づくりの流れ', 'akarui-house' ),
				'singular_name' => __( '流れのステップ', 'akarui-house' ),
				'add_new_item'  => __( 'ステップを追加', 'akarui-house' ),
				'edit_item'     => __( 'ステップを編集', 'akarui-house' ),
				'all_items'     => __( 'ステップ一覧', 'akarui-house' ),
			),
			'public'              => true,
			'publicly_queryable'  => false,  /* 個別ページは持たない */
			'exclude_from_search' => true,
			'has_archive'         => false,
			'menu_position'       => 6,
			'menu_icon'           => 'dashicons-editor-ol',
			'supports'            => array( 'title', 'editor', 'page-attributes' ),
			'show_in_rest'        => true,
		)
	);
}
add_action( 'init', 'akarui_register_post_types' );

/**
 * 管理画面の一覧を並び順（menu_order）の昇順にする
 */
function akarui_admin_order( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}
	$pt = $query->get( 'post_type' );
	if ( in_array( $pt, array( 'works', 'flow' ), true ) && ! $query->get( 'orderby' ) ) {
		$query->set( 'orderby', 'menu_order' );
		$query->set( 'order', 'ASC' );
	}
}
add_action( 'pre_get_posts', 'akarui_admin_order' );

/**
 * 管理画面の一覧に「並び順」と「写真」の列を足す
 */
function akarui_works_columns( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		if ( 'title' === $key ) {
			$new['akarui_thumb'] = __( '写真', 'akarui-house' );
		}
		$new[ $key ] = $label;
	}
	$new['akarui_order'] = __( '並び順', 'akarui-house' );
	return $new;
}
add_filter( 'manage_works_posts_columns', 'akarui_works_columns' );

function akarui_flow_columns( $columns ) {
	$columns['akarui_order'] = __( '並び順', 'akarui-house' );
	return $columns;
}
add_filter( 'manage_flow_posts_columns', 'akarui_flow_columns' );

function akarui_custom_column( $column, $post_id ) {
	if ( 'akarui_thumb' === $column ) {
		if ( has_post_thumbnail( $post_id ) ) {
			echo get_the_post_thumbnail( $post_id, array( 72, 46 ) );
		} else {
			echo '<span style="color:#c00">' . esc_html__( '未設定', 'akarui-house' ) . '</span>';
		}
	}
	if ( 'akarui_order' === $column ) {
		echo (int) get_post_field( 'menu_order', $post_id );
	}
}
add_action( 'manage_works_posts_custom_column', 'akarui_custom_column', 10, 2 );
add_action( 'manage_flow_posts_custom_column', 'akarui_custom_column', 10, 2 );

/**
 * 建築事例カードの PROJECT 番号。
 * menu_order が入っていればそれを、無ければ一覧上の並び順を使う。
 *
 * @param int $fallback ループ内の連番（0 起点）。
 * @return string 例：PROJECT_01
 */
function akarui_project_label( $fallback = 0 ) {
	$order = (int) get_post_field( 'menu_order', get_the_ID() );
	$num   = $order > 0 ? $order : ( (int) $fallback + 1 );
	return 'PROJECT_' . str_pad( (string) $num, 2, '0', STR_PAD_LEFT );
}

/**
 * 有効化直後にパーマリンクを作り直す（/works/ が 404 になるのを防ぐ）
 */
function akarui_flush_rewrite() {
	akarui_register_post_types();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'akarui_flush_rewrite' );
