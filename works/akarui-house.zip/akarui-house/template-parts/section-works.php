<?php
/**
 * 建築事例セクション（カスタム投稿タイプ works）
 *
 * @package Akarui_HOUSE
 */

$akarui_works = new WP_Query(
	array(
		'post_type'      => 'works',
		'posts_per_page' => 4,
		'orderby'        => 'menu_order date',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	)
);
?>
<section class="works" id="works">
	<div class="container">
		<h2 class="sec-title sec-title--light"><?php esc_html_e( '建築事例を紹介', 'akarui-house' ); ?></h2>

		<?php if ( $akarui_works->have_posts() ) : ?>
			<ul class="works__list">
				<?php
				$akarui_i = 0;
				while ( $akarui_works->have_posts() ) :
					$akarui_works->the_post();
					?>
					<li class="card">
						<a class="card__link" href="<?php the_permalink(); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php
								the_post_thumbnail(
									'akarui-card',
									array(
										'class'   => 'card__img',
										'loading' => 'lazy',
									)
								);
								?>
							<?php else : ?>
								<img class="card__img" src="<?php echo esc_url( get_theme_file_uri( '/img/project1.jpg' ) ); ?>"
								     alt="" width="880" height="560" loading="lazy">
							<?php endif; ?>
							<span class="card__label"><?php echo esc_html( akarui_project_label( $akarui_i ) ); ?></span>
						</a>
					</li>
					<?php
					++$akarui_i;
				endwhile;
				wp_reset_postdata();
				?>
			</ul>
		<?php else : ?>
			<ul class="works__list">
				<?php for ( $akarui_i = 1; $akarui_i <= 4; $akarui_i++ ) : ?>
					<li class="card">
						<span class="card__link">
							<img class="card__img"
							     src="<?php echo esc_url( get_theme_file_uri( '/img/project' . $akarui_i . '.jpg' ) ); ?>"
							     alt="" width="880" height="560" loading="lazy">
							<span class="card__label"><?php echo esc_html( sprintf( 'PROJECT_%02d', $akarui_i ) ); ?></span>
						</span>
					</li>
				<?php endfor; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>
